//
//  Frog.cpp
//  Zuma
//
//  Created by Fady Fady on 12/25/22.
//  Copyright © 2022 Fady Fady. All rights reserved.
//

#include "Frog.hpp"

Frog::Frog(RenderWindow &w)
{
    Count = 0;
    //To set size of the Frog
    //this->setSize(Vector2f(w.getSize().x / 5.7, w.getSize().y / 2.7));
    RectangleShape::setSize(Vector2f(1.5*158.f,1.5*353.f));
    this->setSize(Vector2f(1.5*158.f,1.5*353.f) );
    
    //To Put the frog at the middle part of the screen
    RectangleShape::setPosition(w.getSize().x / 2 , w.getSize().y / 2 + 500 );
    this->setPosition(w.getSize().x / 2 , w.getSize().y / 2 + 500 );
    //To Set the Image of Zuma
    zumafrog.loadFromFile("/Users/mm/Desktop/ZumaFinalISA/ZumaFinalISA/Cup.png");
    RectangleShape::setTexture(&zumafrog);
    //To Set the origin of the Frog
    RectangleShape::setOrigin((this->getPosition().x + this->getSize().x / 2 ) / 5.5 - 110, (this->getPosition().y + this->getSize().y / 2 ) / 5.5);
        
}

float Frog::findAngle(Vector2f& pos1, Vector2f& pos2)
{
    float dx = pos2.x - pos1.x;
    float dy = pos2.y - pos1.y;
    float radian = atan2f(dy, dx);
    return (radian * 180 / 3.14);
}

Vector2f Frog::getPosition()
{
    return RectangleShape::getPosition();
}

Vector2f Frog::getSize()
{
    return RectangleShape::getSize();
}

//To Rotate the Frog with the mouse with the given angle of the mouse
void Frog::setRotation(Vector2f &m)
{
    float dx = m.x - this->getPosition().x;
    float dy = m.y - this->getPosition().y;
    float radian = atan2f(dy, dx) + M_PI/2;
    RectangleShape::setRotation(radian * 180 / M_PI);
}

//To Draw the Frog on the screen
void Frog::draw(RenderWindow & w)
{
    w.draw((RectangleShape)*this);
}

//To Check for the center of the frog at anyplace
Vector2f Frog::frogCenter()
{
    return Vector2f(this->getPosition().x + this->getSize().x / 2 - 150, this->getPosition().y + this->getSize().y / 2 - 150);
}
