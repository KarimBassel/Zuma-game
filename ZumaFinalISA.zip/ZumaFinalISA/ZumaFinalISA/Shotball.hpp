#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <ctime>
#include "Frog.hpp"

using namespace std;
using namespace sf;


class Shotball : public CircleShape
{
public:
   
    Vector2f currVelocity;
    float maxSpeed;
        
    Shotball(Frog frog)
        : currVelocity(0.f, 0.f), maxSpeed(35.f)
    {
        
        switch (rand() % 5)
        {
            case 0: this->setFillColor(Color::Red);
                break;
            case 1: this->setFillColor(Color::Cyan);
                break;
            case 2: this->setFillColor(Color::Blue);
                break;
            case 3: this->setFillColor(Color::Yellow);
                break;
            default: this->setFillColor(Color::Green);
                break;
        }
        this->setRadius(40.f);
        this->setPosition(frog.frogCenter());
    }


    Vector2f ShotCenter(Frog frog)
    {
        return Vector2f(frog.getPosition().x + frog.getSize().x / 2 - 25, frog.getPosition().y + frog.getSize().y / 2 - 40);
    }

    Color getFillColor()
    {
        return CircleShape::getFillColor();
    }

    Vector2f getPosition()
    {
        return CircleShape::getPosition();
    }

    void move(Vector2f velocity)
    {
        CircleShape::move(velocity);
    }

    FloatRect getGlobalBounds()
    {
        return CircleShape::getGlobalBounds();
    }

    void draw(RenderWindow& w)
    {
        w.draw((CircleShape)*this);
    }
};
