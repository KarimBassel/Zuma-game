#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <math.h>
#include <vector>
#include <cstdlib>

#include "Frog.hpp"
#include "Shotball.hpp"
#include "Balls.hpp"

using namespace std;
using namespace sf;


//int main()
//{
//    RenderWindow window(VideoMode(2400, 1600), "Zuma Game", Style::Close);
//    window.setFramerateLimit(60);
//
//    srand(time(NULL));
//
//    int checker = 0;
//    Vector2f ShotCenter;
//    Vector2f MousePosWindow;
//    Vector2f aimDir;
//    Vector2f aimDirNorm;
//    Vector2f lineMotion;
//    Vector2f downMotion;
//
//    int shotTimer = 0;
//
//    //To Set the Size of the Frog
//    Frog f1(window);
//    //f1.setFillColor(Color::Blue);
//
//    //To Set the Background
//    RectangleShape Background (Vector2f(window.getSize().x, window.getSize().y));
//    Texture back;
//
//    //To set the ending Star
//    RectangleShape Star(Vector2f(200.f,200.f));
//    Texture dead;
//    Star.setFillColor(Color::Red);
//
//    int x = 0, y = 0;
//    //For Line balss
//    /*CircleShape ball;
//    ball.setFillColor(Color::Blue);
//    ball.setRadius(40.f);
//    ball.setPosition(x, y);
//    ball.setOutlineColor(Color::Black);
//
//    vector<CircleShape> balls;
//    balls.push_back(ball);*/
//
//    /*Listball ballsline;
//    vector<CircleShape> ballsVec;
//    CircleShape* balls = new CircleShape();
//    for (int i = 0; i < 10; i++)
//    {
//        ballsline.insert(*balls, i);
//        ballsVec.push_back(*balls);
//        //delete balls;
//        balls = new CircleShape();
//    } */
//
//    //To insert the balls in a line
//    int a = 0;
//    Balls list ;
//    CircleShape* ball[10];
//    ball[0]= new CircleShape();
//    ball[0]->setFillColor(Color::Blue);
//    ball[0]->setPosition((a = a - 160.f), 0.f);
//    ball[0]->setRadius(80.f);
//    list.insert(*ball[0], 0);
//
//
//
//    for (int i = 1; i < 10; i++)
//    {
//        ball[i] = new CircleShape();
//        switch (rand() % 5)
//        {
//        case 0: ball[i]->setFillColor(Color::Red);
//            break;
//        case 1: ball[i]->setFillColor(Color::Cyan);
//            break;
//        case 2: ball[i]->setFillColor(Color::Blue);
//            break;
//        case 3: ball[i]->setFillColor(Color::Yellow);
//            break;
//        default: ball[i]->setFillColor(Color::Green);
//            break;
//        }
//        ball[i]->setPosition((i * (- 160.f)), 0.f);
//        ball[i]->setRadius(80.f);
//        list.insert(*ball[i], i);
//        //ball = new CircleShape();
//    }
//
//    //Line.push_back(list);
//
//
//    //For Shooting balls
//    Shotball* s1 = new Shotball(f1);
//    vector<Shotball> bullets;
//    Shotball* s2 = s1;
//    s1->setPosition(f1.getPosition().x-100.f, f1.getPosition().y-100.f);
//    s1->setRadius(80.f);
//
//    //To Know the Color of the ball to be shot
//    CircleShape shotcolor;
//    shotcolor.setFillColor(s1->getFillColor());
//    shotcolor.setRadius(40.f);
//    shotcolor.setPosition(f1.getPosition().x - 1100 , f1.getPosition().y + f1.getSize().y / 2 - 40);
//    shotcolor.setOutlineColor(Color::Black);
//    shotcolor.setOutlineThickness(7);
//
//
//    //To Check if the Background is loaded or not
//    if (!back.loadFromFile("/Users/mm/Desktop/Zuma/Zuma/Background.png"))
//    {
//        cout << "Load Failer" << endl;
//        system("pause");
//    }
//    Background.setTexture(&back);
//
//    //To Check if the Image is loaded or not
//    Image dead1;
////    dead1.loadFromFile("Dead.png");
////    dead.loadFromImage(dead1);
//    if (!dead.loadFromFile("/Users/mm/Desktop/Zuma/Zuma/Dead.png"))
//    {
//        cout << "Load Failer" << endl;
//        system("pause");
//    }
//    Star.setTexture(&dead);
//    Star.setPosition(2000.f, 800.f);
//
//    while (window.isOpen() && !(list.empty()))
//    {
//        Event eventxd;
//        while (window.pollEvent(eventxd))
//        {
//            //ShotCenter = Vector2f(frog.getPosition().x + frog.getSize().x / 2 - 25, frog.getPosition().y + frog.getSize().y / 2 - 40);
//            MousePosWindow = Vector2f(Mouse::getPosition(window));
//            aimDir = MousePosWindow - f1.frogCenter();
//            float s = sqrt(pow(aimDir.x, 2) + pow(aimDir.y, 2));
//            aimDirNorm = (aimDir / s);
//            lineMotion = Vector2f(4.f, 0.f);
//            downMotion = Vector2f(-3200.f, 200.f);
//
//            switch (eventxd.type)
//            {
//            case Event::Closed:
//                window.close();
//
//                break;
//
//             //For Creating Shot balls
//            case Event::MouseButtonPressed:
//                {
//
//                 s1->currVelocity = aimDirNorm * s1->maxSpeed;
//
//                 bullets.push_back(*s1);
//
//                 //cout << ++f1.Count << endl;
//                 s2 = s1;
//
//                 delete s1;
//                 s1 = new Shotball(f1);
//                    s1->setRadius(80.f);
//                    s1->setPosition(f1.getPosition().x-100.f, f1.getPosition().y-100.f);
//
//                    break;
//                }
//                break;
//            }
//        }
//
//        shotcolor.setFillColor(s1->getFillColor());
//        f1.setRotation(MousePosWindow);
//        window.clear();
//        window.draw(Background);
//        window.draw(Star);
//        f1.draw(window);
//        window.draw(shotcolor);
//
//        //For Moving the Balls in a line
//
//        for (int i = 0; i < list.mySize; i++)
//        {
//            if (list.getPosition(i).x < 3000)
//                list.move(lineMotion , i);
//            else
//            {
//                list.move(downMotion , i);
//            }
//        }
//
//
//
//        //For Moving the Balls in a line
//        /*for (size_t i = 0; i < 10; i++)
//        {
//            if (ballsline.getAtIndex(i).data.getPosition().y > 400)
//            {
//                ballsline.getAtIndex(i).data.move(-150.f, -500.f);
//            }
//
//            ballsline.getAtIndex(i).data.move(7.f, 0.f);
//
//            //To make the ball move in another down line
//            if (ballsline.getAtIndex(i).data.getPosition().x >= 1200)
//            {
//                ballsline.getAtIndex(i).data.move(-1800.f, 100);
//
//            }
//
//            window.draw(ballsline.getAtIndex(i).data);
//
//        }*/
//
//        /*for (size_t i = 0; i < 10; i++)
//        {
//            if (ball.getPosition().x > 400)
//            {
//                ball.move(-150.f, -500.f);
//            }
//
//            ball.move(7.f, 0.f);
//
//            //To make the ball move in another down line
//            if (ball.getPosition().x >= 1200)
//            {
//                ball.move(-1800.f, 100);
//
//            }
//
//            window.draw(ball);
//
//        }*/
//
////        for (int i = 0; i < list.mySize; i++)
////        {
////            list.draw(window, i);
////        }
//        for (int i = 0; i < list.mySize; i++)
//        {
//            list.draw(window, i);
//        }
//        //For Shotting balls in all direction
//        for (size_t i = 0; i < bullets.size(); i++)
//        {
//            bullets[i].move(bullets[i].currVelocity);
//
//            //To Erase any ball that exit the screen if it doesn't collide with other balls
//            if (bullets[i].getPosition().x < 0 || bullets[i].getPosition().x > window.getSize().x
//                || bullets[i].getPosition().y < 0 || bullets[i].getPosition().y > window.getSize().y)
//            {
//                bullets.erase(bullets.begin() + i);
//                //cout << --f1.Count << endl;
//
//            }
//            //For the collision of the shotball and the lineball
//            else
//            {
//                for (int k = 0; k < list.mySize ; k++)
//                {
////                    if ((bullets[i].getGlobalBounds().intersects(list.getGlobalBounds(0)) && (bullets[i].getFillColor()!=list.getFillColor(0))))
////                    {
////                        list.insert(*s2,0);
////                        continue;
////                    }
//                    if (bullets[i].getGlobalBounds().intersects(list.getGlobalBounds(k)))
//                    {
//                        int index = list.getIndex(bullets[i].getGlobalBounds());
//
//                        bullets.erase(bullets.begin());
//                        //list.destroy( *s2 ,list.getIndex(list.getGlobalBounds(k)));
////                        if(list.getFillColor(k)==s2->getFillColor())
////                            list.destroy(*s2,list.getIndex(list.getGlobalBounds(k)));
//                        if(list.getFillColor(index)==bullets[i].getFillColor())
//                        {
//                            if(list.mySize==0) exit(0);
//                            while(list.getFillColor(index)==bullets[i].getFillColor())
//                            {
//                                    list.erase(list.getIndex(bullets[i].getGlobalBounds()));
//                                if (checker++ == 0) list.erase(0);
//                                if(list.mySize==0){
//                                    cout<<"Ben7ebak ya Dr.Ashraf <3..GG"<<endl;
//                                    break;
//                                }
//                            }
//                            if(list.mySize==0) exit(0);
//                            while(list.getFillColor(index==0?index:index-1)==bullets[i].getFillColor())
//                            {
//                                    list.erase(list.getIndex(bullets[i].getGlobalBounds()));
//                                if (checker++ == 0) list.erase(0);
//                                if(list.mySize==0)
//                                {
//                                    cout<<"Ben7ebak ya Dr.Ashraf <3..GG"<<endl;
//                                    break;
//                                }
//                            }
//                            if(list.mySize==0) exit(0);
//                        }
//                        else
//                        {
//   //                         list.swap(index, bullets[i]);
//     //                       list.draw(window,index);
//                        }
//                        cout<<list.mySize<<endl;
//                        break;
//                    }
//                 }
//            }
//        }
//        if(list.mySize==0)
//        {
//            cout<<"you won!"<<endl;
//            break;
//        }
//
//
//        for (size_t i = 0; i < bullets.size(); i++)
//        {
//            bullets[i].draw(window);
//        }
//
//        if (list.getGlobalBounds(0).intersects(Star.getGlobalBounds()) && list.getPosition(0).x >= 1020)
//        {
//            list.erase(0);
//            cout << "Game Over" << endl;
//            break;
//        }
//
//        window.display();
//    }
//
//    return 0;
//}
int main()
{
    RenderWindow window(VideoMode(2400, 1600), "Zuma Game", Style::Close);
    window.setFramerateLimit(60);

    srand(time(NULL));
    int won=0;
    won++;
    if(won>100){
        cout<<"Bn7ebak ya Dr"<<endl;
        exit(0);
    }
    int checker = 0;
    Vector2f ShotCenter;
    Vector2f MousePosWindow;
    Vector2f aimDir;
    Vector2f aimDirNorm;
    Vector2f lineMotion;
    Vector2f downMotion;

    int shotTimer = 0;

    //To Set the Size of the Frog
    Frog f1(window);
    //f1.setFillColor(Color::Blue);
    
    //To Set the Background
    RectangleShape Background (Vector2f(window.getSize().x, window.getSize().y));
    Texture back;

    //To set the ending Star
    RectangleShape Star(Vector2f(350.f,350.f));
    //Star.rotate(90);
    Texture dead;
    //Star.setFillColor(Color::Red);
   
    int x = 0, y = 0;
    //For Line balss
    /*CircleShape ball;
    ball.setFillColor(Color::Blue);
    ball.setRadius(40.f);
    ball.setPosition(x, y);
    ball.setOutlineColor(Color::Black);

    vector<CircleShape> balls;
    balls.push_back(ball);*/

    /*Listball ballsline;
    vector<CircleShape> ballsVec;
    CircleShape* balls = new CircleShape();
    for (int i = 0; i < 10; i++)
    {
        ballsline.insert(*balls, i);
        ballsVec.push_back(*balls);
        //delete balls;
        balls = new CircleShape();
    } */

    //To insert the balls in a line
    Texture ballWC22;
    ballWC22.loadFromFile("/Users/mm/Downloads/IMG_6455.JPG");
    int a = 0;
    Balls list ;
    CircleShape* ball[10];
    ball[0]= new CircleShape();
    ball[0]->setFillColor(Color::Blue);
    ball[0]->setPosition((a = a - 160.f), 50.f);
    ball[0]->setRadius(80.f);
    ball[0]->setTexture(&ballWC22);
    list.insert(*ball[0], 0);
    
   
    
    for (int i = 1; i < 10; i++)
    {
        ball[i] = new CircleShape();
        switch (rand() % 5)
        {
        case 0: ball[i]->setFillColor(Color::Red);
            break;
        case 1: ball[i]->setFillColor(Color::Cyan);
            break;
        case 2: ball[i]->setFillColor(Color::Blue);
            break;
        case 3: ball[i]->setFillColor(Color::Yellow);
            break;
        default: ball[i]->setFillColor(Color::Green);
            break;
        }
        ball[i]->setPosition((i * (- 160.f)), 50.f);
        ball[i]->setRadius(80.f);
        ball[i]->setTexture(&ballWC22);
        list.insert(*ball[i], i);
        //ball = new CircleShape();
    }

    //Line.push_back(list);
   

    //For Shooting balls
    Shotball* s1 = new Shotball(f1);
    vector<Shotball> bullets;
    Shotball* s2 = s1;
    s1->setPosition(f1.getPosition().x-100.f, f1.getPosition().y-100.f);
    s1->setRadius(80.f);
    s1->setTexture(&ballWC22);
   
    //To Know the Color of the ball to be shot
    CircleShape shotcolor;
    shotcolor.setFillColor(s1->getFillColor());
    shotcolor.setRadius(60.f);
    shotcolor.setPosition(f1.getPosition().x - 1100 , f1.getPosition().y + f1.getSize().y / 2 -200);
    shotcolor.setOutlineColor(Color::Black);
    shotcolor.setOutlineThickness(7);
    shotcolor.setTexture(&ballWC22);


    //To Check if the Background is loaded or not
    if (!back.loadFromFile("/Users/mm/Desktop/ZumaFinalISA/ZumaFinalISA/IMG_6463.PNG"))
    {
        cout << "Load Failer" << endl;
        system("pause");
    }
    Background.setTexture(&back);

    //To Check if the Image is loaded or not
    Image dead1;
//    dead1.loadFromFile("Dead.png");
//    dead.loadFromImage(dead1);
    if (!dead.loadFromFile("/Users/mm/Desktop/ZumaFinalISA/ZumaFinalISA/GoalTop.png"))
    {
        cout << "Load Failer" << endl;
        system("pause");
    }
    Star.setTexture(&dead);
    Star.setPosition(2200.f, 625.f);
    

    while (window.isOpen() && !(list.empty()))
    {
        Event eventxd;
        while (window.pollEvent(eventxd))
        {
            //ShotCenter = Vector2f(frog.getPosition().x + frog.getSize().x / 2 - 25, frog.getPosition().y + frog.getSize().y / 2 - 40);
            MousePosWindow = Vector2f(Mouse::getPosition(window));
            aimDir = MousePosWindow - f1.frogCenter();
            float s = sqrt(pow(aimDir.x, 2) + pow(aimDir.y, 2));
            aimDirNorm = (aimDir / s);
            lineMotion = Vector2f(6.f, 0.f);
            downMotion = Vector2f(-3200.f, 200.f);

            switch (eventxd.type)
            {
            case Event::Closed:
                window.close();

                break;

             //For Creating Shot balls
            case Event::MouseButtonPressed:
                {
                
                 s1->currVelocity = aimDirNorm * s1->maxSpeed;

                 bullets.push_back(*s1);

                 //cout << ++f1.Count << endl;
                 s2 = s1;

                 delete s1;
                 s1 = new Shotball(f1);
                    s1->setRadius(80.f);
                    s1->setPosition(f1.getPosition().x-100.f, f1.getPosition().y-100.f);
                    s1->setTexture(&ballWC22);
                    
                    break;
                }
                break;
            }
        }

        shotcolor.setFillColor(s1->getFillColor());
        f1.setRotation(MousePosWindow);
        window.clear();
        window.draw(Background);
        window.draw(Star);
        f1.draw(window);
        window.draw(shotcolor);

        //For Moving the Balls in a line
        
        for (int i = 0; i < list.mySize; i++)
        {
            won=0;
            won++;
            if(won>100){
                cout<<"Bn7ebak ya Dr"<<endl;
                exit(0);
            }
            if (list.getPosition(i).x < 3000)
                list.move(lineMotion , i);
            else
            {
                list.move(downMotion , i);
            }
        }
        
        

        //For Moving the Balls in a line
        /*for (size_t i = 0; i < 10; i++)
        {
            if (ballsline.getAtIndex(i).data.getPosition().y > 400)
            {
                ballsline.getAtIndex(i).data.move(-150.f, -500.f);
            }

            ballsline.getAtIndex(i).data.move(7.f, 0.f);

            //To make the ball move in another down line
            if (ballsline.getAtIndex(i).data.getPosition().x >= 1200)
            {
                ballsline.getAtIndex(i).data.move(-1800.f, 100);
                
            }

            window.draw(ballsline.getAtIndex(i).data);
           
        }*/

        /*for (size_t i = 0; i < 10; i++)
        {
            if (ball.getPosition().x > 400)
            {
                ball.move(-150.f, -500.f);
            }

            ball.move(7.f, 0.f);

            //To make the ball move in another down line
            if (ball.getPosition().x >= 1200)
            {
                ball.move(-1800.f, 100);

            }

            window.draw(ball);

        }*/

//        for (int i = 0; i < list.mySize; i++)
//        {
//            list.draw(window, i);
//        }
        for (size_t i = 0; i < bullets.size(); i++)
        {
            won=0;
            won++;
            if(won>100)
            {
                cout<<"Bn7ebak ya Dr.. GG"<<endl;
                exit(0);
            }
            bullets[i].draw(window);
        }

        for (int i = 0; i < list.mySize; i++)
        {
            won=0;
            won++;
            if(won>100)
            {
                cout<<"Bn7ebak ya Dr.. GG"<<endl;
                exit(0);
            }
            list.draw(window, i);
        }
        //For Shotting balls in all direction
        for (size_t i = 0; i < bullets.size(); i++)
        {
            won=0;
            won++;
            if(won>100)
            {
                cout<<"Bn7ebak ya Dr.. GG"<<endl;
                exit(0);
            }
            bullets[i].move(bullets[i].currVelocity);

            //To Erase any ball that exit the screen if it doesn't collide with other balls
            if (bullets[i].getPosition().x < 0 || bullets[i].getPosition().x > window.getSize().x
                || bullets[i].getPosition().y < 0 || bullets[i].getPosition().y > window.getSize().y)
            {
                bullets.erase(bullets.begin() + i);
                //cout << --f1.Count << endl;
       
            }
            //For the collision of the shotball and the lineball
            else
            {
                for (int k = 0; k < list.mySize ; k++)
                {   won=0;
                    won++;
                    if(won>100)
                    {
                        cout<<"Bn7ebak ya Dr.. GG"<<endl;
                        exit(0);
                    }
//                    if ((bullets[i].getGlobalBounds().intersects(list.getGlobalBounds(0)) && (bullets[i].getFillColor()!=list.getFillColor(0))))
//                    {
//                        list.insert(*s2,0);
//                        continue;
//                    }
                    if (bullets[i].getGlobalBounds().intersects(list.getGlobalBounds(k)))
                    {
                        cout<<"collision";
                        int index = list.getIndex(bullets[i].getGlobalBounds());
                        int maxIndex = index+1, minIndex = index-1;
//                        if(index==list.mySize || index == list.mySize-1)
//                        {
//                            if (list.getFillColor(list.mySize)==list.getFillColor(list.mySize-1))
//                            {
//                                list.erase(list.mySize-1);
//                                list.erase(list.mySize-2);
//                                break;
//                            }
//                        }
//                        if (index==list.mySize-2)
//                        {
//                            list.erase(list.mySize-2);
//                            break;
//                        }
                        if (bullets[i].getFillColor()==list.getFillColor(index))
                        {
                            if(checker++==0)
                                list.erase(0);
                            if (list.mySize==3 && list.getFillColor(0)==list.getFillColor(list.mySize))
                            {
                                cout<<"enta gamed"<<endl;
                                exit(0);
                            }
                            if (list.mySize==4 && ((list.getFillColor(0) == list.getFillColor(1)) && (list.getFillColor(1) == list.getFillColor(list.mySize))))
                            {
                                cout<<"enta gamed"<<endl;
                                exit(0);
                            }
                           
                            if(index==0 || index==list.mySize)
                            {
                                list.erase(index);
                                continue;
                            }
//                             if(list.gg(index)){
//                                 cout<<"GG gdn";
//                             exit(0);
//                            }
                            while(list.getFillColor(minIndex<0?minIndex=0:minIndex)==list.getFillColor(index))
                            {
                                won=0;
                                won++;
                                if(won>100)
                                {
                                    cout<<"Bn7ebak ya Dr.. GG"<<endl;
                                    exit(0);
                                }
                                if (index==minIndex)
                                    break;
                                minIndex--;
                            }
                            while(list.getFillColor(maxIndex>=list.mySize?maxIndex=list.mySize-1:maxIndex)==list.getFillColor(index))
                            {
                                won=0;
                                won++;
                                if(won>100)
                                {
                                    cout<<"Bn7ebak ya Dr.. GG"<<endl;
                                    exit(0);
                                }
                                if (index==maxIndex)
                                    break;
                                maxIndex++;
                            }
                            while(list.getFillColor(maxIndex)==list.getFillColor(minIndex))
                            {
                                won=0;
                                won++;
                                if(won>100)
                                {
                                    cout<<"Bn7ebak ya Dr.. GG"<<endl;
                                    exit(0);
                                }
                                minIndex--;
                                maxIndex++;
                            }
                            if(maxIndex-minIndex==list.mySize)
                            {
                                cout<<"mabrook ya 3'aly"<<endl;
                                exit(0);
                            }
                            if ((list.getFillColor(0) == list.getFillColor(list.mySize-1)) && index == 1)
                            {
                                cout<<"GG"<<endl;
                                exit(0);
                            }
                            if (list.mySize<=2)
                            {
                                list.erase(index);
                            }
//                            list.eraseMultiple(maxIndex-minIndex-1, minIndex+1);

                                
                            for (int i = minIndex ; i < maxIndex-1 ; i++)
                            {
                                won=0;
                                won++;
                                if(won>100)
                                {
                                    cout<<"Bn7ebak ya Dr.. GG"<<endl;
                                    exit(0);
                                }
                                if(checker++==0)
                                    list.erase(0);
                                list.erase(minIndex+1);

                            }
                            if (list.mySize==0)
                            {
                                cout<<"GG"<<endl;
                                exit(0);
                            }
                        }
                        cout<<list.mySize<<endl;
                        break;
                    }
                 }
            }
        }
        if(list.mySize==0)
        {
            cout<<"you won!"<<endl;
            break;
        }

       
       
        if (list.getGlobalBounds(0).intersects(Star.getGlobalBounds()) && list.getPosition(0).x >= 1100)
        {
            won=0;
            won++;
            if(won>100)
            {
                cout<<"Bn7ebak ya Dr.. GG"<<endl;
                exit(0);
            }
            list.erase(0);
            cout << "Game Over" << endl;
            break;
        }
       
        window.display();
    }

    return 0;
}
