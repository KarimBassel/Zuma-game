#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <math.h>
using namespace std;
using namespace sf;
#pragma once


class Frog : public RectangleShape
{
public:
    Texture zumafrog;
    int Count;

    Frog(RenderWindow &w);
//    {
//        Count = 0;
//        //To set size of the Frog
//        this->setSize(Vector2f(w.getSize().x / 5.7, w.getSize().y / 2.7));
//        //To Put the frog at the middle part of the screen
//        this->setPosition(w.getSize().x / 2 , w.getSize().y / 2 + 200 );
//        //To Set the Image of Zuma
//        zumafrog.loadFromFile("Zuma2.png");
//        RectangleShape::setTexture(&zumafrog);
//        //To Set the origin of the Frog
//        RectangleShape::setOrigin((this->getPosition().x + this->getSize().x / 2 ) / 5.5, (this->getPosition().y + this->getSize().y / 2 ) / 5.5);
//
//    }

    float findAngle(Vector2f& pos1, Vector2f& pos2);
//    {
//        float dx = pos2.x - pos1.x;
//        float dy = pos2.y - pos1.y;
//        float radian = atan2f(dy, dx);
//        return (radian * 180 / 3.14);
//    }
    
    Vector2f getPosition();
//    {
//        return RectangleShape::getPosition();
//    }

    Vector2f getSize();
//    {
//        return RectangleShape::getSize();
//    }

    //To Rotate the Frog with the mouse with the given angle of the mouse
    void setRotation(Vector2f &m);
//    {
//        float dx = m.x - this->getPosition().x;
//        float dy = m.y - this->getPosition().y;
//        float radian = atan2f(dy, dx) + M_PI/2;
//        RectangleShape::setRotation(radian * 180 / M_PI);
//    }

    //To Draw the Frog on the screen
    void draw(RenderWindow & w);
//    {
//        w.draw((RectangleShape)*this);
//    }

    //To Check for the center of the frog at anyplace
    Vector2f frogCenter();
//    {
//        return Vector2f(this->getPosition().x + this->getSize().x / 2 - 150, this->getPosition().y + this->getSize().y / 2 - 150);
//    }


};
